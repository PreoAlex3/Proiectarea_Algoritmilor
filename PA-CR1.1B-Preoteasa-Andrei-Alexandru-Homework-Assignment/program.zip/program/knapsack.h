#ifndef KNAPSACK_H_INCLUDED
#define KNAPSACK_H_INCLUDED

void generare(int n,int *val,int *profit);
int profit_metoda_1(int C, int *val, int *profit, int n);
int profit_metoda_2(int C, int *val, int *profit, int n);
int maxim(int x,int y);
#endif // KNAPSACK_H_INCLUDED
